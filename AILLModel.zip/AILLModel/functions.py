from sklearn.preprocessing import LabelEncoder

def label_encoder(df, columns):
    for column in columns:
        le = LabelEncoder()
        df[column] = le.fit_transform(df[column])
    return df