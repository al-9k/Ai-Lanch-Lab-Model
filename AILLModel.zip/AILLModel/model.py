import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from functions import *
import joblib

csv_url = "https://raw.githubusercontent.com/al-9k/Kaggle-Test/main/collegePlace.csv"

df = pd.read_csv(csv_url)
df.drop_duplicates(keep='first', inplace=True)
df = df.reset_index(drop=True)

df = label_encoder(df, df.columns)

X = df.drop('PlacedOrNot', axis=1)
y = df['PlacedOrNot']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

rf_classifier = RandomForestClassifier(random_state = 42)
rf_classifier.fit(X_train, y_train)

joblib.dump(rf_classifier, 'model.pkl')

y_pred = rf_classifier.predict(X_test)

print(classification_report(y_test, y_pred))
