from functions import *
import pandas as pd
import joblib
import numpy as np

model = joblib.load('model.pkl')

data = {
    'Age': [22, 25, 24, 28, 25, 21, 29, 25, 27, 23],
    'Gender': ['Male', 'Male', 'Female', 'Male', 'Female', 'Female', 'Male', 'Female', 'Female', 'Male'],
    'Stream': ['Electronics And Communication', 'Mechanical', 'Mechanical', 'Computer Science', 'Computer Science',
               'Electronics And Communication', 'Mechanical', 'Electronics And Communication', 'Electronics And Communication', 'Mechanical'],
    'Internships': [2, 4, 2, 3, 5, 1, 5, 0, 5, 3],
    'CGPA': [8, 5, 6, 7, 9, 9, 7, 5, 9, 8]
}

df = pd.DataFrame(data)

df = label_encoder(df, df.columns)

prediction = model.predict(df)
uncertainty = np.max(model.predict_proba(df), axis=1) * 100

for pred, uncert in zip(prediction, uncertainty):
    if pred == 1:
        pred_text = 'Placed'
    else:
        pred_text = 'Not Placed'
    print(f"Prediction: {pred_text} \t | \t Certainty: {uncert:.1f}%")
    print('----------------------------------------------------')